package com.axis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AxisBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AxisBackendApplication.class, args);
	}

}