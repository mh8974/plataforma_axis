package com.axis.model;


public enum StatusCadastro {
    
    PENDENTE,

    
    APROVADO,

    
    REPROVADO
}
