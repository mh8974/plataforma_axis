package com.axis.model;


public enum StatusToken {
    ATIVO,
    USADO,
    EXPIRADO,
    INVALIDADO
}
