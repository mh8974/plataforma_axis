package com.axis.model;

public enum Role {
    PACIENTE,
    TERAPEUTA,
    ADMINISTRADOR
}