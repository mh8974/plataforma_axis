import React from "react";
import CadastroSistema from "@/components/shared/CadastroSistema";

const CadastroProfissionalPage: React.FC = () => {
  return <CadastroSistema />;
};

export default CadastroProfissionalPage;
