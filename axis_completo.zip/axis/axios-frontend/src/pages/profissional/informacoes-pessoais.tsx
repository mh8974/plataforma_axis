import React from "react";
import InformacoesPessoaisContainer from "@/components/formulario-profissional/informacoes-pessoais/InformacoesPessoaisContainer";

const InformacoesPessoaisPage: React.FC = () => {
  return <InformacoesPessoaisContainer />;
};

export default InformacoesPessoaisPage;