import React from "react";
import CadastroSistema from "@/components/shared/CadastroSistema";

const CadastroPacientePage: React.FC = () => {
  return <CadastroSistema />;
};

export default CadastroPacientePage;
